<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Schedule::command('bib:actualizar-prestamos-vencidos')->dailyAt('06:00');
Schedule::command('bib:generar-recordatorios-prestamos')->dailyAt('06:10');
